## Shipping Label Maker

```
Please extract the files into a folder
* Run npm install
* user gulp command to start the application
* browse: http://localhost:8443
```
